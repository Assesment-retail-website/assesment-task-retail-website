package com.spring.store.demo.models;

public enum ItemType {
    GROCERY,
    CLOTHES,
    TECHNOLOGY,
    OTHER
}
