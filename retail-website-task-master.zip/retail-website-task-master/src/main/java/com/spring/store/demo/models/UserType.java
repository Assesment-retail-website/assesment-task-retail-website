package com.spring.store.demo.models;

public enum UserType {
	EMPLOYEE, AFFILIATE, CUSTOMER
}
